(() => {
  const root = document.getElementById('architecture');
  if (!root) return;
  const details = {
  "02": {
    "tag": [
      "01 / ARRIVAL",
      "01 / 到达"
    ],
    "title": [
      "Sense arrival",
      "感知人员到达"
    ],
    "copy": [
      "An exterior camera would detect approaching people and estimate group size, giving the space time to prepare. Entry or a request confirms use; approaching alone does not confirm a need for service.",
      "场外摄像头拟检测人员接近并估计人数，为空间准备争取时间；由进入或使用请求确认实际使用，人员靠近本身不代表需要服务。"
    ]
  },
  "03": {
    "tag": [
      "02 / CONDITIONS",
      "02 / 状态"
    ],
    "title": [
      "Read heat + energy",
      "读取热环境与能源"
    ],
    "copy": [
      "Heat, light and available PV or stored energy would inform cooling timing and intensity. Air-quality inputs depend on the sensors installed, helping select suitable airflow and air treatment.",
      "将热环境、光照与可用光伏或储能共同用于判断制冷时机与强度；空气质量输入取决于实际传感器配置，用于选择合适的通风与空气处理方式。"
    ]
  },
  "04": {
    "tag": [
      "03 / RESPONSE",
      "03 / 响应"
    ],
    "title": [
      "Ready the room",
      "准备可用空间"
    ],
    "copy": [
      "Within host-approved rules, AI and control logic would coordinate opening, shade, airflow and cooling, then display when the space is ready. Seating and available drinking water are provided through the space and its operator.",
      "在场地方批准的规则内，AI 与控制逻辑拟协调开合、遮阳、通风与制冷，并显示空间可用状态；座位和可获得的饮水由空间设施与运营方提供。"
    ]
  },
  "06": {
    "tag": [
      "04 / FEEDBACK",
      "04 / 反馈"
    ],
    "title": [
      "Learn from use",
      "从使用中改进"
    ],
    "copy": [
      "Experience ratings, observation and interviews would show whether workers can enter, rest and feel comfortable. Feedback informs control settings, space design and operating arrangements.",
      "通过体验评价、观察和访谈检验工人是否能够进入、休息并感到舒适；反馈用于改进控制设置、空间设计与运营安排。"
    ]
  }
};
  const buttons = [...root.querySelectorAll('[data-concept-node]')];
  const setPair = (selector, pair) => {
    ['en', 'zh'].forEach((lang, index) => {
      root.querySelector(`${selector} [data-${lang}]`).textContent = pair[index];
    });
  };
  buttons.forEach(button => button.addEventListener('click', () => {
    const key = button.dataset.conceptNode;
    const detail = details[key];
    if (!detail) return;
    root.dataset.selected = key;
    buttons.forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    setPair('.concept-detail-number', detail.tag);
    setPair('#concept-detail-title', detail.title);
    setPair('#concept-detail-copy', detail.copy);
  }));
})();
